from django.db import models



class product(models.Model):
    product_name = models.TextField()
    product_dis = models.TextField()
    image = models.ImageField(null=True)
    price =  models.TextField(null=True)
    data = models.DateTimeField(auto_now_add=True, null=True)
    
def __str__(self) -> str:
   return self.product_name