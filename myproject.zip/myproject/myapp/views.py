from django.shortcuts import render
from django.shortcuts import render, HttpResponse
from .models import *


def index(request):
  return render(request, 'index.html')
def contact(request):
    return render(request, 'contact.html')
def about(request):
    return render(request, 'about.html')
def store(request):

    products = product.objects.all()
    data = {
        'product':products
    }
    return render(request, 'store.html', data)
